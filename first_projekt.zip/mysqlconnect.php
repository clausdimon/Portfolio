<?php
$servername ="localhost";
$username = "ncln01.skp-dp.sd";
$password = "54p3z2qz";
$dbname = "ncln01_skp_dp_sde_dk";
?>