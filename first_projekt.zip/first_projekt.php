<?php
    require("mysqlconnect.php");
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed;" . $conn->connect_error);
    }
    $sql = "SELECT*FROM portfolio_projekter ORDER BY ID ASC LIMIT 1";
    $result = $conn->query($sql);
    $list = array();
    while($row=mysqli_fetch_array($result,MYSQLI_ASSOC)){
         $list = array(
            'id' => $row['ID'],
            'Title' => $row["Title"],
            'Resume' => $row["Resume"],
            'Picture' => $row['Picture'],
            'all' => $row['Hole_text']
        );
        /* $list = array(
            $row['ID'],
            $row["Title"],
            $row["Resume"],
            $row['Picture'],
            $row['Hole_text']
        ); */
        /* echo "ID: ".$row['ID'];
        echo "<br>Title: ".$row['Title'];
        echo "<br>Resume: ".$row["Resume"];
        echo "<br>Picture: ".$row['Picture'];
        echo "<br>all: ".$row['Hole_text']; */
              

    }
    foreach($list as $x){
        echo $x ."<br>";
    }
    $json = json_encode($list);
    var_dump($json);
    die();
    //echo $json['id'];
?>